<?php

class ValueError extends Error
{
}
