<head>
<style>
    .text_content
    {
    max-height: 350px;
    overflow-y: scroll;
    }
</style>
</head>  
 <h5 class="card-title"><b><?php echo get_phrase("text_content"); ?></b></h5>
<div class="text_content">
        <?php echo $lesson_details['text_content']; ?>
</div>