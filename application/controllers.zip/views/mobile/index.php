<!DOCTYPE html>
<html>

<head>
	<?php include 'includes_top.php'; ?>
</head>

<body data-layout="detached">
	<!-- HEADER -->
	<?php include $page_name . '.php'; ?>
	<!-- all the js files -->
	<?php include 'includes_bottom.php'; ?>
	<?php include 'payment_model.php'; ?>
</body>

</html>
