
<!DOCTYPE html>
<html lang="en">
<head>

	
<title>Entiretycourses</title>
  
<meta property="title" content="Entiretycourses"/>
<meta property="og:title" content="Entiretycourses"/>

 <link rel="canonical" href="https://courses.entiretyin.com/"/> <meta name="copyright" content="entiretyin">  
<meta name="description" content="Everyone needs attention, but you need people to observe and appreciate your child's activities, we entirety people oversee the interests and make sure to enhance the best online course platform in entiretyin.Design for managing the overall school system in online like class,Exams,Activity,event,etc....">

<meta property="og:type" content="Entiretyin Course - Student Enhancement Platform"/>   
<meta property="og:url" content="https://courses.entiretyin.com/"/>
<meta property="og:url" content="https://courses.entiretyin.com/home"/>
<link rel="canonical" href="https://courses.entiretyin.com/"/>
		<meta name="keywords" content="School enhancement platform,Entiretyin Course,Entiretyin Course,courses entiretyin,telangana startup,affordable price, course entiretyin, online course Platform,affordable price ,Entiretyin Course, Entiretyin Course,internships,Entiretyin Course,affordable price,affordable price,ted talk,Entiretycourses,certificate,courses entiretyinstudent Management system software, course entiretyin,Entiretycourse, Entiretycourses,Entiretycourses, Entiretyin Course,Entiretycourses,Entiretycourses,entiretyin Pvt Ltd,entirety in Pvt Ltd,Entiretyin Course,courses entiretyin,entirety in Pvt Ltd,entirety in Pvt Ltd,entirety in Pvt Ltd,online course Platform,online course Platform,entiretyin Pvt Ltd,course entiretyin, entiretyin Pvt Ltd,affordable price,entirety in Pvt Ltd,Entiretyin Course,internships,Entiretycourses,telangana startup,Entiretycourses,Entiretycourses,certificate,entirety in Pvt Ltd,course entiretyin ,Entiretycourses,online course Platform, course entiretyin, career opportunity,student Management system software,courses entiretyinstudent enhancement system entiretyin,Entiretycourses,school enhancement system ,Entiretycourses,telangana startup,Entiretycourses,entirety in Pvt Ltd,course entiretyin, entiretyin Pvt Ltd,career entiretyin,certificate ,course entiretyin,affordable price,courses entiretyin,careers,Entiretycourses,online course Platform,telangana startup,entirety in Pvt Ltd, entiretyin Pvt Ltd, entiretyin,Entiretyin Course,Entiretycourses, course entiretyin,online course Platform, entiretyin Pvt Ltd,student enhancement system, career opportunity,courses entiretyin,student enhancement platform,career entiretyin ,Entiretyin Course, entiretyin Pvt Ltd,careers,affordable price,internships,Entiretyin Course,online course Platform,entirety in Pvt Ltd,Entiretyin Course,entirety in Pvt Ltd,course entiretyin,student enhancement software entiretyin,EntiretycoursesEntiretycourses,,online school Management system,Entiretycourses,ted talk, entiretyin Pvt Ltd,online course Platform,career opportunity,entirety in Pvt Ltd,course entiretyin,telangana startup,Entiretyin Course,online course Platform,career entiretyin, school Management software entiretyin, student Management system,Entiretycourses,courses entiretyin, career opportunity, course entiretyin, Entiretyin Courseentirety in Pvt Ltd, online course Platform,entiretyin,Entiretycourses,entiretyin,affordable price, Entiretyin Course,school administrative system,online course Platform,ted talk,entirety in Pvt Ltd,course entiretyin, Entiretycourses,Entiretycourses,students administrative system,entirety in Pvt Ltd,career opportunity,Entiretycourses, entiretyin Pvt Ltd, course entiretyin,online course Platform, careers student Management system software,course entiretyin,Entiretycourses, course entiretyin,Entiretyin Course entiretyin Pvt Ltd, student information software,Entiretycourses,Entiretycourses,career opportunity,careers,online course Platform,career entiretyin,  course entiretyin, entiretyin Pvt Ltd,Entiretycourses,courses entiretyin,Entiretyin Course,online course Platform,entirety in Pvt Ltd, affordable price,certificate, course entiretyin, course entiretyin,online course Platform,Entiretycourses,Entiretycourses,online course Platform,Entiretyin Course,online course Platform,entiretyin Pvt Ltd,entirety in Pvt Ltd" />


		
		<meta name="description" content="Everyone needs attention, but you need people to observe and appreciate your child's activities, we entirety people oversee the interests and make sure to enhance the best online course platform in entiretyin.Design for managing the overall school system in online like class,Exams,Activity,event,etc....">
	
	
	<?php if($page_name == "Entiretycourses"): ?>
		<meta property="og:image" content="<?php echo $this->crud_model->get_course_thumbnail_url($course_id); ?>">
	<?php else: ?>
		<meta property="og:image" content="<?= base_url("uploads/system/".get_frontend_settings('banner_image')); ?>">
	<?php endif; ?>
	
	<!--Whatsapp-->

	<link name="favicon" type="image/x-icon" href="<?php echo base_url('uploads/system/'.get_frontend_settings('favicon')); ?>" rel="shortcut icon" />
	<?php include 'includes_top.php';?>

</head>
<body class="gray-bg"page_name="website" page_sub_name="course">
	<?php
	if ($this->session->userdata('user_login')) {
		include 'logged_in_header.php';
	}else {
		include 'logged_out_header.php';
	}

	if(get_frontend_settings('cookie_status') == 'active'):
    	include 'eu-cookie.php';
  	endif;
  	
  	if($page_name === null){
  		include $path;
  	}else{
		include $page_name.'.php';
	}
	include 'footer.php';
	include 'includes_bottom.php';
	include 'modal.php';
	include 'common_scripts.php';
	?>
</body>
</html>
