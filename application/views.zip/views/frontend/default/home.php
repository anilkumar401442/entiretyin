<head>
<title>Entiretycourses - online course Platform </title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
  

<meta property="title" content="Entiretycourse - online course Platform "/>

<meta property="og:title" content="Entiretycourse - online course Platform "/>



 <link rel="canonical" href="https://courses.entiretyin.com/"/> <meta name="copyright" content="entiretycourses">  

<meta name="description" content="Everyone needs attention, but you need people to observe and appreciate your child's activities, we entirety people oversee the interests and make sure to enhance the best online course platform in entiretyin.Design for managing the overall school system in online like class,Exams,Activity,event,etc....">

<meta property="og:type" content="website"/>

<meta property="og:type" content="https://courses.entiretyin.com/"/>   

<meta property="og:url" content="https://courses.entiretyin.com/"/>

<meta property="og:url" content="https://courses.entiretyin.com/home"/>

<link rel="canonical" href="https://courses.entiretyin.com/home">

<meta name="keywords" content="entiretycourse,Eniretyin course,entirety of the course,
eniretyin,eniretyin pvt ltd,entirety in pvt ltd,entirety in pvt ltd hyderabad,entirety in pvt ltd,
course entiretyin,entiretycourse,entirety of the course,entirety in pvt ltd,Eniretyin course,eniretyin pvt ltd,entiretycourse,entiretyin course,home eniretyin,enitrtyin home,Eniretyin course"/>


<meta name="description" content="Everyone needs attention, but you need people to observe and appreciate your child's activities, we entirety people oversee the interests and make sure to enhance the best online course platform in entiretyin.Design for managing the overall school system in online like class,Exams,Activity,event,etc....">

  

<link  href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/css/bootstrap.min.css">



<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/js/bootstrap.min.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js" integrity="sha512-XtmMtDEcNz2j7ekrtHvOVR4iwwaD6o/FUJe6+Zq+HgcCsk3kj4uSQQR8weQ2QVj1o0Pk6PwYLohm206ZzNfubg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css" integrity="sha512-17EgCFERpgZKcm0j0fEq1YCJuyAWdz9KUtv1EjVuaOz8pDnh/0nZxmU6BBXwaaxqoi9PQXnRWqlcDB027hgv9A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.css" integrity="sha512-wR4oNhLBHf7smjy0K4oqzdWumd+r5/+6QO/vDda76MW5iug4PT7v86FoEkySIJft3XA0Ae6axhIvHrqwm793Nw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<!--<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=0403e02f-8e05-436b-aa7b-c61a9940b5c8"> </script>-->
</head>

<style>

    body{

        width: 100%;

        overflow-x: hidden;



    }

    

    .st{

        width: 100%;





        display: flex;

        flex-direction: row;

        justify-content: space-around;

        flex-wrap: wrap;



    }

   .card{

        position: relative;

        max-width: 600px;

        height: auto;

        background: #fff;

        border-radius:1px;

       margin-left: 50px !important;

        margin-right:10px !important;

       

        

        margin:30px;

        box-shadow: 0 6px 10px rgba(0,0,0,.08), 0 0 6px rgba(0,0,0,.05);

        overflow: hidden;

        transition: 0.5s;





    }



      .card:hover{



         background-image: linear-gradient(to right, #32be8f, #38d39f, #32be8f);



}



    .card .content{

        padding: 23px;

        text-align: center;



    }



     .card .content i{

        position: absolute;

        right:260px;

        font-size: 3.5em;

        font-weight: bold;

        color: #21c87a;

        align-items: center;

        opacity: 0.1;

        transition: 0.5s;





    }



     .card:hover .content i{

        color: #fff;

        opacity:1;

        







    }

    .card .content h3{

        position:relative;

        font-size: 1.5em;

        color: #21c87a;

        z-index: 2;

        top: 0px;

         font-weight: bold;

        letter-spacing: 1px;

        transition: 0.5s;



    }



.card .content p{

        position:relative;

        font-size: 1.2em;

        color: #696965;

        z-index: 2;

         font-weight: 400;

       

        letter-spacing: 1px;

        transition: 0.5s;



    }

 .card:hover .content h3, .card:hover .content p{

        color:#fff;

opacity: 1;



}

 .card .content a{

display: inline-block;

margin-top: 15px;

padding: 8px 15px;

background: #ffff;

color: #0c002b;

text-decoration: none;

text-transform: uppercase;

font-weight: 600;









}



 .card span{

    transition: 0.5;

    opacity: 0;

}

 .card:hover span{

      opacity: 1;







    }

 .card span:nth-child(1){

    position: absolute;

    top: 0;

    left: 0;

    width: 100%;

    height: 5px;

    background: linear-gradient(to right, transparent, #ffff);

    animation: animate1  2s linear infinite;



}



@keyframes animate1 {

    0%{

        transform: translateX(-100%);



    }



    100%{

        transform: translateX(100%);



    }

}



 .card span:nth-child(2){

    position: absolute;

    top: 0;

    right: 0;

    width: 5px;

    height: 100%;

    background: linear-gradient(to bottom, transparent, #fff);

    animation: animate2  2s linear infinite;

    animation-delay: 1s;

}



@keyframes animate2 {

    0%{

        transform: translateY(-100%);



    }



    100%{

        transform: translateY(100%);



    }

}



 .card span:nth-child(3){

    position: absolute;

    bottom: 0;

    left: 0;

    width: 100%;

    height: 5px;

    background: linear-gradient(to left, transparent, #fff);

    animation: animate3  2s linear infinite;



}



@keyframes animate3 {

    0%{

        transform: translateX(100%);



    }



    100%{

        transform: translateX(-100%);



    }

}



.card span:nth-child(4){

    position: absolute;

    top: 0;

    left: 0;

    width: 5px;

    height: 100%;

    background: linear-gradient(to top, transparent, #fff);

    animation: animate4  2s linear infinite;

    animation-delay: 1s;

}



@keyframes animate4 {

    0%{

        transform: translateY(100%);



    }



    100%{

        transform: translateY(-100%);



    }

}



@media screen and (max-width:600px ){

            .container .card{

            flex:100%;

            max-width: 600px;

           }



          





    }

.contain{

         

           width: 100%;

          display: flex;

        flex-direction: row;

        justify-content: space-around;

        flex-wrap: wrap;



}





 .card-4{

    position: relative;

   

    margin-left: 50px;

    height: 360px;

  margin-right: 50px;

    padding: 10px 15px;

    

   overflow: hidden;

   

    background-color: #fff;

    transition: 0.5s ease-in-out;

box-shadow: 0 6px 10px rgba(0,0,0,.08), 0 0 6px rgba(0,0,0,.05);

}

 .card-4:hover{



    height: 590px;



}



@media screen and (max-width:600px ){

             .card-4{

            flex:100%;

            max-width:400px;

            height: 330px;



           }

           .needhide{

            display:none; 



           }

           .needctr{

            margin-right: -7rem;

           }

           .ctitle{

           margin-top: -30px; ;





}

            .head{

                font-size: 18px;

            }





          





    }

.contain .card-4 .imgbx{

    position: relative;

    width: 100%;

    height: 240px;

    

     

    z-index: 1;

  



}

.bn{

    text-align:center;

    width: : auto;



}

.heart{

    font-size: 25px;

    text-align: center;

}





.contain .card-4 .imgbx img{



max-width: 100%;

border-radius:4px;





}

.content .h6{

    text-align: left;

}



.contain .card-4 .content{

    top: 20px;

    position: relative;

    margin-top: -140px;

    padding: 10px 10px;

    text-align: center;

    

    visibility: hidden;

    opacity: 0;

    transition: 0.3s ease-in-out;

    text-align: justify;

    color:#696965;

    font-style: 'Open Sans', sans-serif;





}





.contain .card-4:hover .content{

    visibility: visible;

    opacity: 1;

    margin-top: -40px;

    transition-delay: 0.3s;

    }





@media(max-width: 990px){

  .card-4{

    margin: 20px;

  }

  .price{

    right: 20px;



  }

  .pric{

    right: 20px !important;

  }

} 



.carousel-indicators{

    left: 0;

    top: auto;

    bottom: -70px;

}

.carousel-indicators li{

    background: #21c87a;

    border-radius: 50%;

    width: 100%;

    height: auto;







    }

    .carousel-indicators .active{

        background: #fff;

    }









.parrow{

 position: relative;

top: -120px;

 left: -13px;

  line-height: 50px;

  text-align: center;

  background: #ffff;

  color: #333;

  cursor: pointer;

  height: 50px;

  width: 50px;

  border-radius: 50%;

  box-shadow: 0 5px 10px #3337;



}

.parrow:hover{

  background: #21c87a;

  color: #fff;



}

.prarrow:hover{

  background: #21c87a;

  color: #fff;



}

.narrow{

 position: relative;

top: -120px;

 right: -1220px;

  line-height: 50px;

  text-align: center;

  background: #ffff;

  color: #333;

  cursor: pointer;

  height: 50px;

  width: 50px;

  border-radius: 50%;

  box-shadow: 0 5px 10px #3337;



}

.narrow:hover{

  background: #21c87a;

  color: #fff;



}

.nearrow:hover{

  background: #21c87a;

  color: #fff;



}

.prarrow{

    position: relative;

top: -120px;

 left: -13px;

  line-height: 50px;

  text-align: center;

  background: #ffff;

  color: #333;

  cursor: pointer;

  height: 50px;

  width: 50px;

  border-radius: 50%;

  box-shadow: 0 5px 10px #3337;





}

.nearrow{

 position: relative;

top: -120px;

 right: -1220px;

  line-height: 50px;

  text-align: center;

  background: #ffff;

  color: #333;

  cursor: pointer;

  height: 50px;

  width: 50px;

  border-radius: 50%;

  box-shadow: 0 5px 10px #3337;



}



.section{

        width: 100%;

        min-height: 100vh;



    }

    .containerjo{

        width: 80%;

        display: block;

        margin: auto;padding-top:30px;



    }

    .learn{

        float: right;

        width: 45%;

        padding-top:-50px;



    }

    .learning_img{

        float: left;

        width:55%;

    }

    .learning_img  img{

             width: 100%;

             height: auto;

    }

    .learn .title h4 {

        font-family: sans-serif;

        margin: 50px;

        color: #21c87a; 

        font-weight: bold;       

        text-align: center;

        

        font-size: 25px;

        max-width: 600px;

        position: relative;

      }

    

      .learn .contentjo h2{



       color: #21c87a;

       font-weight: bold;

}

.learn .contentjo p{

        color: #696965;

         font-size: 18px;

       text-align: justify;

}

.learn .contentjo span{

        color: #696965;

         font-size: 17px;

       text-align: justify;

}



.icon1, .icon2{

           color: #21c87a;

       }

    



@media screen and (max-width: 1000px){

    

    .learn{

        float: none;

        width:auto;

        display:block;

        margin:auto;

        margin-left: 20px;

        padding-top:20%;



    }

    .learning_img{

        float: none;

        width:auto;

        display:block;

        margin:auto;

        margin-left: 20px;

        padding-top: 20%;



    }

    

}


.flow-sec{
  background-color: #58D68D;
    width:1250px;
    margin: 50px auto;

    margin-top: 40px;
   max-height: auto;
box-shadow: 0 10px 20px rgba(0,0,0,.12), 0 4px 8px rgba(0,0,0,.06);
}

.tab-input {
  position: absolute;
  opacity: 0;
  z-index: -1;
}

.row .col:last-child {
  margin-left: 2em;
  margin-right:40px;
}

/* Accordion styles */
.tabs {
  
  overflow: hidden;
  box-shadow: 0 4px 4px -2px rgba(0, 0, 0, 0.5);
    margin-bottom: 60px;
}

.faq {
  width: 100%;
  color: #58D68D;

overflow: hidden;
  
}
.table-label{
  display: flex;
  justify-content: space-between;
   color: #58D68D;
  padding: 1em;
  background: #ffff;
  font-weight: bold;
  font-size: 17px;
font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
  cursor: pointer;

    border: 3px solid #58D68D;
    
}

.table-label::after {
  content: "❯";
  
    transform: rotate(-90deg);
  
  transition: all 0.35s;
  width: 31px;
  height: 31px;
  
  text-align: center;
  border:3px solid #58D68D;
  border-radius: 50%;
}
.tab-content {
  max-height: 0;
  padding: 0 1em;
  color: #fff;
  font-size: 19px;
  font-family: "Open-Sans",sans-serif !important ;
 font-weight: bold;
  background: #58D68D;
 border: 2px solid #fff;

  transition: all 0.35s;
  border-top: none;
border-bottom: none;
}
.tab-close {
  display: flex;
  justify-content: flex-end;
  padding: 1em;
  font-size: 0.75em;

  cursor: pointer;
}


input:checked + .table-label {
  background: #fff;
}
input:checked + .table-label::after {
  transform: rotate(90deg);
}
input:checked ~ .tab-content {
  max-height: 100vh;
  padding: 1em;
}

.acc-head{
 margin-bottom: 100px;
  margin-left:250px;
  margin-top: -150px;


}
.acc-head h4{
  text-align: center;
  margin-top: 20px;
  color: #ffff;
  font: 16px karla,sans-serif;
  font-weight: bold;

} 
.acc-head h1{
  text-align: center;
  margin-top: 20px;

  color: #ffff;

  font-size: 55px;
}
.acc-head hr{
  width: 70px;
  background-color: #ffff;
  height:1.5px;

}
.img{
  width: 300px;

  height: auto;
  margin-top:-20px; 
  margin-left: 100px;
}
    
    @media screen and (max-width: 1000px){
.flow-sec{
  margin-top:50px;

    width:100%;
  
   max-height:auto;

}
.acc-head h4{
  text-align: center;
  margin-top: 200px;
   color: #ffff;
  font: 16px karla,sans-serif;
  font-weight: bold;

} 
.acc-head h1{
  text-align: center;
  margin-top: 20px;
  color: #ffff;
 font-size: 55px;
}
.acc-head hr{
  width: 70px;
  background-color: #ffff;
  height:1.5px;
}
.acc-head{
       margin-top: -200px;
       margin-left:10px;
}

.img{
  display: none;
  }

}


  .one img{
     box-shadow: 0 6px 10px rgba(0,0,0,.08), 0 0 6px rgba(0,0,0,.05);
     margin-left:20px;
     margin-right:0px;
     width:95%;

  }
  
.two img{
    display: none;
  }
    
@media screen and (max-width:500px) {
  .one img{
    display: none;
  }

  .two img{
  width:90%;
  margin-left: 20px;
  height: auto;
    display: block;
  }
}

</style>
<section class="home-banner-area" style="background-image: url('<?= base_url("uploads/system/".get_frontend_settings('banner_image')); ?>');

        background-position: center center;

        background-size: cover;

        background-repeat: no-repeat;

        padding: 170px 0 130px;

        color: #fff;">

    <div class="container-lg">

        <div class="row">

            <div class="col">

                <div class="home-banner-wrap">

                    <h2><?php echo get_frontend_settings('banner_title'); ?></h2>

                    <p><?php echo get_frontend_settings('banner_sub_title'); ?></p>

                    <form class="" action="<?php echo site_url('home/search'); ?>" method="get">

                        <div class="input-group">

                            <input type="text" class="form-control" name = "query" placeholder="<?php echo site_phrase('what_do_you_want_to_learn'); ?>?">

                            <div class="input-group-append">

                                <button class="btn" type="submit"><i class="fas fa-search"></i></button>

                            </div>

                        </div>

                    </form>

                </div>

            </div>

        </div>

    </div>

</section>

<section class="home-fact-area">

    <div class="container-lg">

        <div class="row">

            <?php $courses = $this->crud_model->get_courses(); ?>

            <div class="col-md-4 d-flex">

                <div class="home-fact-box mr-md-auto mr-auto">

                    <i class="fas fa-bullseye float-left"></i>

                    <div class="text-box">

                        <h4><?php

                        $status_wise_courses = $this->crud_model->get_status_wise_courses();

                        $number_of_courses = $status_wise_courses['active']->num_rows();

                        echo $number_of_courses.' '.site_phrase('online_courses'); ?></h4>

                        <p><?php echo site_phrase('explore_a_variety_of_fresh_topics'); ?></p>

                    </div>

                </div>

            </div>



            <div class="col-md-4 d-flex">

                <div class="home-fact-box mr-md-auto mr-auto">

                    <i class="fa fa-check float-left"></i>

                    <div class="text-box">

                        <h4><?php echo site_phrase('expert_instruction'); ?></h4>

                        <p><?php echo site_phrase('find_the_right_course_for_you'); ?></p>

                    </div>

                </div>

            </div>



            <div class="col-md-4 d-flex">

                <div class="home-fact-box mr-md-auto mr-auto">

                    <i class="fa fa-clock float-left"></i>

                    <div class="text-box">

                        <h4><?php echo site_phrase('lifetime_access'); ?></h4>

                        <p><?php echo site_phrase('learn_on_your_schedule'); ?></p>

                    </div>

                </div>

            </div>

        </div>

    </div>

</section>



<section class="course-carousel-area">

    <div class="container-lg">

        <div class="">

            <div class="">

                <h3 class="text-center" style="margin-bottom:40px;"><?php echo site_phrase('top_courses'); ?></h3>

                 <div class="contain slide">

                    <?php $top_courses = $this->crud_model->get_top_courses()->result_array();

                    $len=count($top_courses);
                    //echo $len;exit;
                    $cnt=round($len/2);

                    if(!empty($top_courses)){

                    if($len > $cnt ){

                            $firsthalf = array_slice($top_courses, 0,$cnt);

                            $secondhalf = array_slice($top_courses, $cnt,$len);

                            }else{

                            $firsthalf = $top_courses;

                            $secondhalf = array();

                        }

                    }
                    //echo '<pre>';print_r($secondhalf);exit;
                    $cart_items = $this->session->userdata('cart_items');

                    foreach ($firsthalf as $top_course):?>

                        

                            <div class="card-4">

							    <a href="<?php echo site_url('home/course/'.rawurlencode(slugify($top_course['title'])).'/'.$top_course['id']); ?>" class="has-popover">

                                <div class="imgbx">

                                    <img style="width:312px !important; height:208px !important;" src="<?php echo $this->crud_model->get_course_thumbnail_url($top_course['id']); ?>" alt="">

                                

                                    <!-- <img  src="assets/home_img/market.jpeg">  -->

                                </div>



                                 <div class="ctitle">

                                    <h5 class="head"><?php echo $top_course['title']; ?></h5>

                                    <!--<p style="font-size: 12px;"><?php echo site_phrase('last_updated').' '.date('D, d-M-Y', $top_course['date_added']); ?></p>-->

                                  

                                    <div class="pric">

                                       <!--  <h5 class="price text-right" style="right:20px;color:#21c87a;font-weight: bold;"><small style="text-decoration: line-through; color:#696965;"> ₹5999</small> ₹1999</h5> -->

                                         <?php if ($top_course['is_free_course'] == 1): ?>

                                    <h5 class="price text-right"><?php echo site_phrase('free'); ?></h5>

                                <?php else: ?>

                                    <?php if ($top_course['discount_flag'] == 1): ?>

                                        <h5 class="price text-right" style="right:20px;color:#21c87a;font-weight: bold;"><small style="text-decoration: line-through; color:#696965;"><?php echo currency($top_course['price']); ?></small><?php echo currency($top_course['discounted_price']); ?></h5>

                                    <?php else: ?>

                                        <h5 class="price text-right"><?php echo currency($top_course['price']); ?></h5>

                                    <?php endif; ?>

                                <?php endif; ?>

                                    </div>

                                </div>

                                </a>								

                                </a>								

								

								

                                    <div class="content">

                                          <?php if($top_course['course_type'] == 'general'): ?>

                                    <span class=""><i class="fas fa-play-circle"></i>

                                        <?php echo $this->crud_model->get_lessons('course', $top_course['id'])->num_rows().' '.site_phrase('lessons'); ?>

                                    </span>

                                    <span class=""><i class="far fa-clock"></i>

                                        <?php

                                        $total_duration = 0;

                                        $lessons = $this->crud_model->get_lessons('course', $top_course['id'])->result_array();

                                        foreach ($lessons as $lesson) {

                                            if ($lesson['lesson_type'] != "other") {

                                                $time_array = explode(':', $lesson['duration']);

                                                $hour_to_seconds = $time_array[0] * 60 * 60;

                                                $minute_to_seconds = $time_array[1] * 60;

                                                $seconds = $time_array[2];

                                                $total_duration += $hour_to_seconds + $minute_to_seconds + $seconds;

                                            }

                                        }

                                        echo gmdate("H:i:s", $total_duration).' '.site_phrase('hours');

                                        ?>

                                    </span>

                                <?php elseif($top_course['course_type'] == 'scorm'): ?>

                                    <span class="badge badge-light"><?= site_phrase('scorm_course'); ?></span>

                                <?php endif; ?>

                                <span class=""><i class="fas fa-closed-captioning"></i><?php echo ucfirst($top_course['language']); ?></span>

                                     <p><?php echo $top_course['short_description']; ?></p>

                                     <ul style="justify-content:center;">

                                            <?php

                                    $outcomes = json_decode($top_course['outcomes']);

                                    foreach ($outcomes as $outcome):?>

                                    <li><?php echo $outcome; ?></li>

                                <?php endforeach; ?>



                                     </ul>

                                    <div class="popover-btns">

                            <?php if (is_purchased($top_course['id'])): ?>

                                <div class="purchased">

                                    <a href="<?php echo site_url('home/my_courses'); ?>"><?php echo site_phrase('already_purchased'); ?></a>

                                </div>

                            <?php else: ?>

                                <?php if ($top_course['is_free_course'] == 1):

                                    if($this->session->userdata('user_login') != 1) {

                                        $url = "#";

                                    }else {

                                        $url = site_url('home/get_enrolled_to_free_course/'.$top_course['id']);

                                    }?>

                                    <a href="<?php echo $url; ?>" class="btn add-to-cart-btn big-cart-button" onclick="handleEnrolledButton()"><?php echo site_phrase('get_enrolled'); ?></a>

                                <?php else: ?>

                                    <button type="button" class="btn btn-success text-center <?php if(in_array($top_course['id'], $cart_items)) echo 'addedToCart'; ?> big-cart-button-<?php echo $top_course['id'];?>"  style="width:250px;" id = "<?php echo $top_course['id']; ?>" onclick="handleCartItems(this)">

                                        <?php

                                        if(in_array($top_course['id'], $cart_items))

                                        echo site_phrase('added_to_cart');

                                        else

                                        echo site_phrase('add_to_cart');

                                        ?>

                                    </button>

                                <?php endif; ?>

                               <!--  <button type="button" class="wishlist-btn <?php if($this->crud_model->is_added_to_wishlist($top_course['id'])) echo 'active'; ?>" title="Add to wishlist" onclick="handleWishList(this)" id = "<?php echo $top_course['id']; ?>"><i class="fas fa-heart"></i></button> -->

                            <?php endif; ?>



                        </div>

                                   <!--   <a href="<?php echo site_url('home/course/entreprenuership-marketing/1'); ?>"class="btn btn-success text-center" style="width:250px;">

                                     Add to cart</a> -->

                            </div>



                                

                            </div>

                        <?php endforeach; ?>     

             </div><br>

             <div class="needhide">

              <div id="next" class="fas fa-chevron-left parrow" ></div>

          <div id="prev" class="fas fa-chevron-right narrow"></div>

      </div>



          

                 <div class="contain slider">

                   <?php $top_courses = $this->crud_model->get_top_courses()->result_array();

                    $len=count($top_courses);

                    $cnt=round($len/2);

                    if(!empty($top_courses)){

                    if($len > $cnt ){

                            $firsthalf = array_slice($top_courses, 0,$cnt);

                            $secondhalf = array_slice($top_courses, $cnt,$len);

                            }else{

                            $firsthalf = $top_courses;

                            $secondhalf = array();

                        }

                    }

                    $array_count = count($secondhalf);

                    $cart_items = $this->session->userdata('cart_items');

                    foreach ($secondhalf as $top_course):?>

                       

                            <div class="card-4">

                                <div class="imgbx">

                                    <a href="<?php echo site_url('home/course/'.rawurlencode(slugify($top_course['title'])).'/'.$top_course['id']); ?>" class="has-popover">

                                  <img style="width:312px !important; height:208px !important;" src="<?php echo $this->crud_model->get_course_thumbnail_url($top_course['id']); ?>" alt="">

                              </a>

                                    <!-- <img  src="assets/home_img/market.jpeg">  -->

                                </div>

                                 <div class="ctitle">

                                    <h5 class="head"> <?php echo $top_course['title']; ?> </h5>

                                    <!--<p style="font-size: 12px;"><?php echo site_phrase('last_updated').' '.date('D, d-M-Y', $top_course['date_added']); ?></p>-->

                                  

                                    <div class="pric">

                                       <!--  <h5 class="price text-right" style="right:20px;color:#21c87a;font-weight: bold;"><small style="text-decoration: line-through; color:#696965;"> ₹5999</small> ₹1999</h5> -->

                                         <?php if ($top_course['is_free_course'] == 1): ?>

                                    <h5 class="price text-right"><?php echo site_phrase('free'); ?></h5>

                                <?php else: ?>

                                    <?php if ($top_course['discount_flag'] == 1): ?>

                                        <h5 class="price text-right" style="right:20px;color:#21c87a;font-weight: bold;"><small style="text-decoration: line-through; color:#696965;"><?php echo currency($top_course['price']); ?></small><?php echo currency($top_course['discounted_price']); ?></h5>

                                    <?php else: ?>

                                        <h5 class="price text-right"><?php echo currency($top_course['price']); ?></h5>

                                    <?php endif; ?>

                                <?php endif; ?>

                                    </div>

                                </div>

                                    

                                      <div class="content">

                                          <?php if($top_course['course_type'] == 'general'): ?>

                                    <span class=""><i class="fas fa-play-circle"></i>

                                        <?php echo $this->crud_model->get_lessons('course', $top_course['id'])->num_rows().' '.site_phrase('lessons'); ?>

                                    </span>

                                    <span class=""><i class="far fa-clock"></i>

                                        <?php

                                        $total_duration = 0;

                                        $lessons = $this->crud_model->get_lessons('course', $top_course['id'])->result_array();

                                        foreach ($lessons as $lesson) {

                                            if ($lesson['lesson_type'] != "other") {

                                                $time_array = explode(':', $lesson['duration']);

                                                $hour_to_seconds = $time_array[0] * 60 * 60;

                                                $minute_to_seconds = $time_array[1] * 60;

                                                $seconds = $time_array[2];

                                                $total_duration += $hour_to_seconds + $minute_to_seconds + $seconds;

                                            }

                                        }

                                        echo gmdate("H:i:s", $total_duration).' '.site_phrase('hours');

                                        ?>

                                    </span>

                                <?php elseif($top_course['course_type'] == 'scorm'): ?>

                                    <span class="badge badge-light"><?= site_phrase('scorm_course'); ?></span>

                                <?php endif; ?>

                                <span class=""><i class="fas fa-closed-captioning"></i><?php echo ucfirst($top_course['language']); ?></span>

                                     <p><?php echo $top_course['short_description']; ?></p>

                                     <ul style="justify-content:center;">

                                            <?php

                                    $outcomes = json_decode($top_course['outcomes']);

                                    foreach ($outcomes as $outcome):?>

                                    <li><?php echo $outcome; ?></li>

                                <?php endforeach; ?>



                                     </ul>

                                    <div class="popover-btns">

                            <?php if (is_purchased($top_course['id'])): ?>

                                <div class="purchased">

                                    <a href="<?php echo site_url('home/my_courses'); ?>"><?php echo site_phrase('already_purchased'); ?></a>

                                </div>

                            <?php else: ?>

                                <?php if ($top_course['is_free_course'] == 1):

                                    if($this->session->userdata('user_login') != 1) {

                                        $url = "#";

                                    }else {

                                        $url = site_url('home/get_enrolled_to_free_course/'.$top_course['id']);

                                    }?>

                                    <a href="<?php echo $url; ?>" class="btn add-to-cart-btn big-cart-button" onclick="handleEnrolledButton()"><?php echo site_phrase('get_enrolled'); ?></a>

                                <?php else: ?>

                                    <button type="button" class="btn btn-success text-center <?php if(in_array($top_course['id'], $cart_items)) echo 'addedToCart'; ?> big-cart-button-<?php echo $top_course['id'];?>"  style="width:250px;" id = "<?php echo $top_course['id']; ?>" onclick="handleCartItems(this)">

                                        <?php

                                        if(in_array($top_course['id'], $cart_items))

                                        echo site_phrase('added_to_cart');

                                        else

                                        echo site_phrase('add_to_cart');

                                        ?>

                                    </button>

                                <?php endif; ?>

                               <!--  <button type="button" class="wishlist-btn <?php if($this->crud_model->is_added_to_wishlist($top_course['id'])) echo 'active'; ?>" title="Add to wishlist" onclick="handleWishList(this)" id = "<?php echo $top_course['id']; ?>"><i class="fas fa-heart"></i></button> -->

                            <?php endif; ?>



                        </div>

                                   <!--   <a href="<?php echo site_url('home/course/entreprenuership-marketing/1'); ?>"class="btn btn-success text-center" style="width:250px;">

                                     Add to cart</a> -->

                            </div>



                                

                            </div>

                        <?php endforeach; ?> 

                        <?php if($array_count == '2'){ ?>

							    <div class="col-md-4"></div>

							<?php }elseif($array_count == '2'){ ?>

								<div class="col-md-4"></div>

								<div class="col-md-4"></div>

							<?php } ?>

                            </div>

                            <div class="needhide">

                             <div id="next" class="fas fa-chevron-left prarrow" ></div>

                            <div id="prev" class="fas fa-chevron-right nearrow"></div>

                            </div>





                        <br>

                        <br>

                       <h3 class="text-center" style="margin-bottom:40px; ">Benefits With Us</h3>

                        <div class="">

                                <div class="row st d-flex">

                                      <div class="">

                            <div class="card">

                                <span></span>

                                <span></span>

                                <span></span>

                                <span></span>

                                <div class="content">
                                    <!--<i class="fa fa-book needctr fa-4x p-2 needctr" aria-hidden="true"></i>-->
                                    <h3>Build Projects</h3>
                                    <p>Internships, projects and practical teaching methods to help you become instantly employable and desirable by the top companies.</p>
                                </div>
                            </div>
                            </div>
                        <div class="">
                            <div class="card">
                                <span></span>

                                <span></span>

                                <span></span>

                                <span></span>

                                <div class="content">

                                    <!--<i class="fa fa-cogs needctr fa-4x p-2" aria-hidden="true"></i>-->

                                    <h3>Start From Scratch</h3>
                                    <p> Want to learn something absolutely new? An open mind is the best place to build a palace! Every course covers the subject from basics.</p>

                                    

                                                    </div>

                                        </div>



                            </div>

                        </div> <br>

                            <div class="row st">

                                <div class="">

                            <div class="card">

                                <span></span>

                                <span></span>

                                <span></span>

                                <span></span>

                                <div class="content">

                                    <!--<i class="fa fa-book needctr fa-4x p-2" aria-hidden="true"></i>-->

                                    <h3>Build Projects</h3>
                                    <p>Internships, projects and practical teaching methods to help you become instantly employable and desirable by the top companies.</p>
                                </div>
                            </div>
                            </div>

                    <div class="">

                            <div class="card">

                                <span></span>

                                <span></span>

                                <span></span>

                                <span></span>

                                <div class="content">

                                   <!--<i class="fa fa-book needctr fa-4x p-2" aria-hidden="true"></i>-->

                                    <h3 style="font-size:18px;">Mentorship & Coaching</h3>

                                    <p>Industry experts to guide you through your course and share their experience. Gain a friend in your field and a coach for life.</p>
                                </div>
                                 </div>
                                </div>

                                </div> 

        
                                 </div>


<section>
        <div class="one">             
      <img src="assets/home_img/ee1.jpg"class="flow-img">
</div> 
<div class="two"> 
      <img src="assets/home_img/j1.jpg"class="res-flo">
      <img src="assets/home_img/fj1.jpg"class="res-flo">
      <img src="assets/home_img/j9.jpeg"class="res-flo">
</div>
</section> 



                    <br><br> 

<br>

            

<script type="text/javascript">

     $('.slide').slick({
          infinite: true,
          speed: 300,
          slidesToShow: 4,
          slidesToScroll: 1,
          autoplay: true,
          autoplaySpeed: 3000,
          prevArrow:'.parrow',
          nextArrow:'.narrow',
          responsive: [
            {
              breakpoint: 1024,
              settings: {
                slidesToShow: 3,
                slidesToScroll: 3,
                infinite: true,
                dots: true
              }
            },
            {
              breakpoint: 700,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 2
              }
            },
            {
              breakpoint: 500,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1
              }
            }
          ]
    });

    $('.slider').slick({

  

  infinite: true,

  speed: 300,

  slidesToShow: 4,

  slidesToScroll: 1,

  autoplay: true,

  autoplaySpeed: 3000,

    prevArrow:'.prarrow',

  nextArrow:'.nearrow',

  responsive: [

    {

      breakpoint: 1024,

      settings: {

        slidesToShow: 3,

        slidesToScroll: 3,

        infinite: true,

        dots: true

      }

    },

    {

      breakpoint: 700,

      settings: {

        slidesToShow: 2,

        slidesToScroll: 2

      }

    },

    {

      breakpoint: 500,

      settings: {

        slidesToShow: 1,

        slidesToScroll: 1

      }

    }

    // You can unslick at a given breakpoint now by adding:

    // settings: "unslick"

    // instead of a settings object

  ]

  

});





</script>

                      <br>

                      <br>

                      <br>

                      <br>

                      <br>

                      <br>

                      <br>

                      <br>





         





















































                

                <!-- Animated page loader 

                <div class="contain">

                       

                       <div class="row"> 

                    <?php $top_courses = $this->crud_model->get_top_courses()->result_array();

                    $cart_items = $this->session->userdata('cart_items');

                    foreach ($top_courses as $top_course):?>

                      

                        <a href="<?php echo site_url('home/course/'.rawurlencode(slugify($top_course['title'])).'/'.$top_course['id']); ?>" >



                                  



                                    

                            <div class="card-4">

                                <div class="imgbx">

                                    <img src="<?php echo $this->crud_model->get_course_thumbnail_url($top_course['id']); ?>" alt="" >

                                </div>

                                <div class="content">

                                    <h5 class=""><?php echo $top_course['title']; ?></h5>

                                    <p class=""><?php echo $top_course['short_description']; ?></p>

                                    

                                <?php if ($top_course['is_free_course'] == 1): ?>

                                    <p class=" text-right"><?php echo site_phrase('free'); ?></p>

                                <?php else: ?>

                                    <?php if ($top_course['discount_flag'] == 1): ?>

                                        <p class=" text-right"><small><?php echo currency($top_course['price']); ?></small><?php echo currency($top_course['discounted_price']); ?></p>

                                    <?php else: ?>

                                        <p class=" text-right"><?php echo currency($top_course['price']); ?></p>

                                    <?php endif; ?>

                                <?php endif; ?>

                            </div>

                        </div>

                        </div>

                        </div>

                        </div>

                    </div>

                    </div>

                    </div>

                    </a>



                    <div class="webui-popover-content">

                        <div class="course-popover-content">

                            <?php if ($top_course['last_modified'] == ""): ?>

                                <div class="last-updated"><?php echo site_phrase('last_updated').' '.date('D, d-M-Y', $top_course['date_added']); ?></div>

                            <?php else: ?>

                                <div class="last-updated"><?php echo site_phrase('last_updated').' '.date('D, d-M-Y', $top_course['last_modified']); ?></div>

                            <?php endif; ?>



                            <div class="course-title">

                                <a href="<?php echo site_url('home/course/'.rawurlencode(slugify($top_course['title'])).'/'.$top_course['id']); ?>"><?php echo $top_course['title']; ?></a>

                            </div>

                            <div class="course-meta">

                                <?php if($top_course['course_type'] == 'general'): ?>

                                    <span class=""><i class="fas fa-play-circle"></i>

                                        <?php echo $this->crud_model->get_lessons('course', $top_course['id'])->num_rows().' '.site_phrase('lessons'); ?>

                                    </span>

                                    <span class=""><i class="far fa-clock"></i>

                                        <?php

                                        $total_duration = 0;

                                        $lessons = $this->crud_model->get_lessons('course', $top_course['id'])->result_array();

                                        foreach ($lessons as $lesson) {

                                            if ($lesson['lesson_type'] != "other") {

                                                $time_array = explode(':', $lesson['duration']);

                                                $hour_to_seconds = $time_array[0] * 60 * 60;

                                                $minute_to_seconds = $time_array[1] * 60;

                                                $seconds = $time_array[2];

                                                $total_duration += $hour_to_seconds + $minute_to_seconds + $seconds;

                                            }

                                        }

                                        echo gmdate("H:i:s", $total_duration).' '.site_phrase('hours');

                                        ?>

                                    </span>

                                <?php elseif($top_course['course_type'] == 'scorm'): ?>

                                    <span class="badge badge-light"><?= site_phrase('scorm_course'); ?></span>

                                <?php endif; ?>

                                <span class=""><i class="fas fa-closed-captioning"></i><?php echo ucfirst($top_course['language']); ?></span>

                            </div>

                            <div class="course-subtitle"><?php echo $top_course['short_description']; ?></div>

                            <div class="what-will-learn">

                                <ul>

                                    <?php

                                    $outcomes = json_decode($top_course['outcomes']);

                                    foreach ($outcomes as $outcome):?>

                                    <li><?php echo $outcome; ?></li>

                                <?php endforeach; ?>

                            </ul>

                        </div>

                        <div class="popover-btns">

                            <?php if (is_purchased($top_course['id'])): ?>

                                <div class="purchased">

                                    <a href="<?php echo site_url('home/my_courses'); ?>"><?php echo site_phrase('already_purchased'); ?></a>

                                </div>

                            <?php else: ?>

                                <?php if ($top_course['is_free_course'] == 1):

                                    if($this->session->userdata('user_login') != 1) {

                                        $url = "#";

                                    }else {

                                        $url = site_url('home/get_enrolled_to_free_course/'.$top_course['id']);

                                    }?>

                                    <a href="<?php echo $url; ?>" class="btn add-to-cart-btn big-cart-button" onclick="handleEnrolledButton()"><?php echo site_phrase('get_enrolled'); ?></a>

                                <?php else: ?>

                                    <button type="button" class="btn add-to-cart-btn <?php if(in_array($top_course['id'], $cart_items)) echo 'addedToCart'; ?> big-cart-button-<?php echo $top_course['id'];?>" id = "<?php echo $top_course['id']; ?>" onclick="handleCartItems(this)">

                                        <?php

                                        if(in_array($top_course['id'], $cart_items))

                                        echo site_phrase('added_to_cart');

                                        else

                                        echo site_phrase('add_to_cart');

                                        ?>

                                    </button>

                                <?php endif; ?>

                                <button type="button" class="wishlist-btn <?php if($this->crud_model->is_added_to_wishlist($top_course['id'])) echo 'active'; ?>" title="Add to wishlist" onclick="handleWishList(this)" id = "<?php echo $top_course['id']; ?>"><i class="fas fa-heart"></i></button>

                            <?php endif; ?>



                        </div>

                    </div>

                </div>

            </div>

        <?php endforeach; ?>

    </div>

</div>

</div>

</div>

</section>-->

<!-- The Modal -->



<div class="modal" id="myModal">

  <div class="modal-dialog">

    <div class="modal-content">



      <!-- Modal Header -->

      <div class="modal-header">

        <h4 class="modal-title">Register to get Discount</h4>

        <button type="button" class="close" data-dismiss="modal">&times;</button>

      </div>



      <!-- Modal body -->

      <div class="modal-body">

        <form action="<?php echo site_url('login/register'); ?>" method="post" id="sign_up">

                  <div class="content-box">

                      <div class="basic-group">

                          <div class="form-group">

                             

                              <input type="text" class="form-control" name = "first_name" id="first_name" placeholder="<?php echo site_phrase('Name'); ?>" value="" required>

                          </div>

                          <div class="form-group">

                              <input type="hidden" class="form-control" value="" name = "last_name" id="last_name" placeholder="<?php echo site_phrase('last_name'); ?>" value="" required>

                          </div>

                          <div class="form-group">

                              <input type="text" class="form-control" name = "mobile" maxlength="10" id="mobile" placeholder="<?php echo site_phrase('mobile'); ?>" value="" required>

                          </div>

                          <div class="form-group">

                              <input type="email" class="form-control" name = "email" id="registration-email" placeholder="<?php echo site_phrase('email'); ?>" value="" required>

                          </div>

                          <div class="form-group">

                              <input type="password" class="form-control" name = "password" id="registration-password" placeholder="<?php echo site_phrase('password'); ?>" value="" required>

                          </div>

                          <?php if(get_frontend_settings('recaptcha_status')): ?>

                            <div class="form-group">

                              <div class="g-recaptcha" data-sitekey="<?php echo get_frontend_settings('recaptcha_sitekey'); ?>"></div>

                            </div>

                          <?php endif; ?>
                          <div class="form-group">
                         <select class="form-control" name="country" id="country" required>
                             <option>Select Country</option>
                             <option value="india">India</option>
                             <option value="usa">USA</option>
                         </select>
                         </div>
                          

                      </div>

                  </div>
                  <div class="content-update-box">
                        <button class="btn" type="submit"><?php echo site_phrase('sign_up'); ?></button>
                  </div>
                  <div class="account-have text-center">
                      <?php echo site_phrase('already_have_an_account'); ?>? <a href="<?php echo base_url(); ?>home/login"><?php echo site_phrase('login'); ?></a>
                  </div>
                      </form>
      </div>
      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="partialModal" role="dialog">
      <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 style="text-align: center;">Payment Pending</h5>
                        <button type="button" class="close" data-dismiss="modal" id="btnClose" aria-label=""><span>×</span></button>
                     </div>
                    
                    <div class="modal-body">
                      <div class="row">
                           <div class="col-md-1"></div>
                           <div class="col-md-11"><h5><?php echo site_phrase('Please_complete_pending_amount_payment'); ?></h5></div>
                           
                      </div><br>
                      <div class="row">
                           <div class="col-md-4"></div>
                           <div class="col-md-3"><button type="button" class="btn btn-primary btn-block checkout-btn" onclick="handleCheckOut('1000')"><?php echo site_phrase('Pay'); ?></button></div>
                            <div class="col-md-4"></div>
                      </div>
                    </div>
                </div>
        </div>
  </div>
  <script type="text/javascript">
    $(document).ready(function() {
        if (localStorage.selectVal) {
        $("#select_country").val( localStorage.selectVal );
    }
    });
    $(document).ready(function (){
        $('#select_country').on('change', function(){
          var country = this.value;
            if (country == 'india') {
              localStorage.setItem('selectVal', country );
              window.location = "<?php echo base_url();?>home";
            }
            if (country == 'usa') {
                localStorage.setItem('selectVal', country );
              window.location = "<?php echo base_url();?>home/home_us";
            }

        });
    });
  </script>
<?php if($this->session->userdata('payment_status') == '0'){ ?>
  <script type="text/javascript">
    $(document).ready(function (){
       $("#partialModal").modal("show");
    });
  </script>
<?php  } ?>
<script type="text/javascript">
$("#btnClose").click(function (e){  
      $.ajax({
        type: "POST",
        url: "<?php echo base_url();?>home/remove_home_popup",
        data:'',
        success: function(data){
          console.log(data);
        }
    });
  });
function handleCheckOut() {
    $.ajax({
        type: "POST",
        url: "<?php echo base_url();?>home/save_partial_amount_homepage_modal",
        data:'',
        success: function(data){
          console.log(data);
        }
    });
    $.ajax({
        url: '<?php echo site_url('home/isLoggedIn');?>',
        success: function(response)
        {
            if (!response) {
                window.location.replace("<?php echo site_url('login'); ?>");
            }else{
                window.location.replace("<?php echo site_url('home/payment'); ?>");
            }
        }
    });
}
function handleWishList(elem) {



    $.ajax({

        url: '<?php echo site_url('home/handleWishList');?>',

        type : 'POST',

        data : {course_id : elem.id},

        success: function(response)

        {

            console.log(response);

            if (!response) {

                window.location.replace("<?php echo site_url('login'); ?>");

            }else {

                if ($(elem).hasClass('active')) {

                    $(elem).removeClass('active')

                }else {

                    $(elem).addClass('active')

                }

                $('#wishlist_items').html(response);

            }

        }

    });

}



function handleCartItems(elem) {

    url1 = '<?php echo site_url('home/handleCartItems');?>';

    url2 = '<?php echo site_url('home/refreshWishList');?>';

    $.ajax({

        url: url1,

        type : 'POST',

        data : {course_id : elem.id},

        success: function(response)

        {

            $('#cart_items').html(response);

            if ($(elem).hasClass('addedToCart')) {

                $('.big-cart-button-'+elem.id).removeClass('addedToCart')

                $('.big-cart-button-'+elem.id).text("<?php echo site_phrase('add_to_cart'); ?>");

            }else {

                $('.big-cart-button-'+elem.id).addClass('addedToCart')

                $('.big-cart-button-'+elem.id).text("<?php echo site_phrase('added_to_cart'); ?>");

            }

            $.ajax({

                url: url2,

                type : 'POST',

                success: function(response)

                {

                    $('#wishlist_items').html(response);

                }

            });

        }

    });

}



function handleEnrolledButton() {

    $.ajax({

        url: '<?php echo site_url('home/isLoggedIn');?>',

        success: function(response)

        {

            if (!response) {

                window.location.replace("<?php echo site_url('login'); ?>");

            }

        }

    });

}



$(document).ready(function(){

    if(! /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {

        if($(window).width() >= 840){

            $('a.has-popover').webuiPopover({

                trigger:'hover',

                animation: 'pop',

                placement:'horizontal',

                delay: {

                    show: 500,

                    hide: null

                },

                width: 330

            });

        }else{

            $('a.has-popover').webuiPopover({

                trigger:'hover',

                animation: 'pop',

                placement:'vertical',

                delay: {

                    show: 100,

                    hide: null

                },

                width: 335

            });

        }

    }

});

</script>

<section class="flow-sec">

<br>
      <br>

                                    
      <img src="assets/home_img/ask42.svg"class="img">
    <div class="acc-head">
    <h4>FREQUENTLY ASKED QUESTIONS</h4>
      
      <h1>Have a Question?</h1>
      <hr>
      </div>
<div class="row">
  <div class="col">
    <div class="tabs">
      <div class="faq">
        <input type="checkbox" id="chck1"class="tab-input">
        <label class="table-label" for="chck1">Why Entiretyin?</label>
        <div class="tab-content">
            Entiretyin focuses on providing you the best services available in the market. We aim 
            to give you top-notch facilities with additional perks, so you make the most of your 
            time. Our motive lies in your welfare, and we only come from a place of good faith.
        </div>
      </div>
      <div class="faq">
        <input type="checkbox" id="chck2"class="tab-input">
        <label class="table-label" for="chck2">How is Entiretyin unique?</label>
        <div class="tab-content">
            Entiretyin offers a peculiar range of courses that are not only special but also 
            important. Most of our courses are also available in regional languages, so you get to 
            learn and acquire knowledge in the best possible way, plus, retain the information. 
            Moreover, expert mentors make it easier for you to grasp the topics with comfort.
        </div>
      </div>
      <div class="faq">
        <input type="checkbox" id="chck3"class="tab-input">
        <label class="table-label" for="chck3">How long would the course material be accessible?</label>
        <div class="tab-content">
            All courses are accessible to the student for an unlimited time period. All material is 
            available for lifetime to the user after the complete payment of the course fee. 

        </div>
      </div>
      <div class="faq">
        <input type="checkbox" id="chck4"class="tab-input">
        <label class="table-label" for="chck4">Are the lessons in the form of pre-recorded videos?</label>
        <div class="tab-content">
            No, Entiretyin offers live classes, so you can clear your doubts and interact with the 
            mentor to extract out maximum productivity. Each course would be led by an 
            experienced mentor, always available to answer questions, even mid-session. 
        </div>
      </div>
      <div class="faq">
        <input type="checkbox" id="chck5"class="tab-input">
        <label class="table-label" for="chck5">Can I get a discount?</label>
        <div class="tab-content">
            Entiretyin offers a unique range of courses that are worth much more than the fee we 
            charge. The prices have been set according to the user’s comfort and monetary 
            leverage. However, we do offer discounts time-to-time. 
        </div>
      </div>
      <div class="faq">
        <input type="checkbox" id="chck6"class="tab-input">
        <label class="table-label" for="chck6">Are there any Q/A sessions?</label>
        <div class="tab-content">
            Yes, each mentor would take mandatory Q/A sessions after every lesson.
        </div>
      </div>
      <div class="faq">
        <input type="checkbox" id="chck7"class="tab-input">
        <label class="table-label" for="chck7">Would I get to do assignments?</label>
        <div class="tab-content">
            Yes, Entiretyin conducts test and assignments on a regular interval to keep your 
            performance in check. With the provided material, you would be able to do your 
            own projects. 
        </div>
      </div>
      <div class="faq">
        <input type="checkbox" id="chck8"class="tab-input">
        <label class="table-label" for="chck8">How do I enrol for a course? </label>
        <div class="tab-content">
            Every course in available under the dropdown of > Courses > Topic > Course Name. 
        </div>
      </div>
      <div class="faq">
        <input type="checkbox" id="chck9"class="tab-input">
        <label class="table-label" for="chck9">Can I pay in instalments?</label>
        <div class="tab-content">
            Entiretyin usually asks for the fee at the time of enrolment. However, you can contact 
            our authorities to discuss your matters and negotiate accordingly, if possible. 
        </div>
      </div>
      <div class="faq">
        <input type="checkbox" id="chck10"class="tab-input">
        <label class="table-label" for="chck10">Can I get a refund if I change my mind? </label>
        <div class="tab-content">
            No, once the transaction is done, it cannot be refunded. 
        </div>
      </div>
      
      

    </div>
  </div>
  
</div>
</section>
